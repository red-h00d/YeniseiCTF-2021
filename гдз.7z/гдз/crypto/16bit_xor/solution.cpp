#include <vector>
#include <iostream>
#include <string>
#include <fstream>

static std::vector<uint8_t> ReadFile(const std::string &i_name)
{
  std::vector<uint8_t> ret;
  std::ifstream fin(i_name);
  if (fin.is_open() == false)
  {
    return ret;
  }

  fin.seekg(0, std::ios_base::end);
  ret.resize(fin.tellg());
  fin.seekg(0, std::ios_base::beg);

  fin.read(reinterpret_cast<char *>(ret.data()), ret.size());
  return ret;
}

static std::vector<uint8_t> ProcessData(std::vector<uint8_t> &i_data, std::vector<uint8_t> &i_key)
{
  std::vector<uint8_t> result;

  for (size_t i = 0, ik = 0; i < i_data.size(); ++i, ik=i % i_key.size())
  {
    uint8_t temp_val;
    temp_val = i_data[i] ^ i_key[ik];
    result.push_back(temp_val);
  }

  return result;
}

int main(int argc, char ** argv)
{
  if (argc != 2)
  {
    return -1;
  }

  std::vector<uint8_t> raw_data = ReadFile(argv[1]);
  
  for (uint16_t i = 0; i < 65536; ++i)
  {
    std::vector<uint8_t> key(2, 0);
    *reinterpret_cast<uint16_t*>(key.data()) = i;
    std::vector<uint8_t> flag = ProcessData(raw_data, key);
    if (flag[0] == 'y' && flag[1] == 'c' && flag[2] == 't' && flag[3] == 'f')
    {
      std::cout << reinterpret_cast<char*>(flag.data()) << std::endl;
      return 0;
    }
  }
  
  return -2;
}
