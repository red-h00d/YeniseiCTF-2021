#include <iostream>
#include <string>
#include <vector>
#include <fstream>

static std::vector<uint8_t> ReadFile(const std::string &i_name)
{
  std::vector<uint8_t> ret;
  std::ifstream fin(i_name);
  if (fin.is_open() == false)
  {
    return ret;
  }

  fin.seekg(0, std::ios_base::end);
  ret.resize(fin.tellg());
  fin.seekg(0, std::ios_base::beg);

  fin.read(reinterpret_cast<char *>(ret.data()), ret.size());
  return ret;
}


static std::vector<uint8_t> DecryptData(const std::vector<uint8_t> &i_data, size_t i_step)
{
  std::vector<uint8_t> result(i_data.size());

  size_t pos = 0;
  for (size_t cs = 0; cs < i_step; ++cs)
  {
    for (size_t i = cs; i < i_data.size(); i += i_step)
    {
      result[i] = i_data[pos++];
    }
  }

  return result;
}


int main(int argc, char ** argv)
{
  if (argc != 2)
  {
    return -1;
  }
  size_t step = 3;

  std::vector<uint8_t> raw_data = ReadFile(argv[1]);

  std::cout << reinterpret_cast<char *>(DecryptData(raw_data, step).data()) << std::endl;

  return 0;
}
