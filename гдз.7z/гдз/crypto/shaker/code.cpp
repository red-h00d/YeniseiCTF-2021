std::vector<uint8_t> EncryptData(const std::vector<uint8_t> &i_data, size_t i_step)
{
  std::vector<uint8_t> result;

  for (size_t cs = 0; cs < i_step; ++cs)
  {
    for (size_t i = cs; i < i_data.size(); i += i_step)
    {
      result.push_back(i_data[i]);
    }
  }

  return result;
}
