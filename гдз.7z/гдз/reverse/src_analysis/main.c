#include <stdio.h>
#include <string.h>

int main() {
    char input[256];

    printf("Enter flag to check: ");
    scanf("%s", input);
    if (strcmp(input, "yctf{7c35fb658e143a496b9ebaff70ca2dc9}") == 0) {
        printf("Yes! Correct flag is %s\n", input);
        return 0;
    }
    printf("Wrong check!\n");
    return 0;
}
