#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define BUFF_SIZE 4096

int save_thought(const char * i_thought)
{
  char command[BUFF_SIZE];
  sprintf(command, "echo %s >> archive.txt", i_thought);
  system(command);

  return 0;
}

int read_thought()
{
  system("shuf -n 1 archive.txt");
  return 0;
}

int main(int argc, char ** argv)
{
  char input[BUFF_SIZE];
  printf("Welcome to our archive of interesting thoughts!\n");
  fflush(stdout);
  
  while (1)
  {
    printf("Choose you destiny\n"
           "[1] Save your thought\n"
           "[2] Read random thought from archive\n"
           "[0] Exit\n"
           "> ");
    fflush(stdout);

    fgets(input, BUFF_SIZE, stdin);

    char * tmp_str = input + strspn(input, " \n");

    if (tmp_str[0] == '1')
    {
      printf("Enter you thought: ");
      fflush(stdout);

      fgets(input, BUFF_SIZE, stdin);
      char * tmp_ptr = strrchr(input, '\n');
      if (tmp_ptr != NULL)
      {
        tmp_ptr[0] = '\0';
      }

      save_thought(input);
    }
    else if (tmp_str[0] == '2')
    {
      printf("There is your thought: ");
      fflush(stdout);

      read_thought();
    }
    else if (tmp_str[0] == '0')
    {
      printf("Goodbye!\n");
      fflush(stdout);

      exit(0);
    }
    else
    {
      printf("Unknown command!\n");
      fflush(stdout);
    }
  }

  return 0;
}
