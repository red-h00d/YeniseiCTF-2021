#include <stdio.h>

#define USER_INPUT 40960

int main(int argc, char * argv[])
{
  char user_input[USER_INPUT];
  const char secret_flag[] = "yctf{dd5f0035d1e48f29710128bc71a353df}";

  printf("Welcome to out simple greeter!\n");

  scanf("%s", user_input);
  printf("Hello, ");
  printf(user_input);
  printf("!\n");

  return 0;
}
