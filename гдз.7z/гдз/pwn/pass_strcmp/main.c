#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define BUFF_SIZE 4096

char* read_file(const char* i_file)
{
  char * ret_str;
  size_t size;
  FILE * f = fopen(i_file, "r");
  if (f)
  {
    fseek(f, 0, SEEK_END);
    size = ftell(f);
    fseek(f, 0, SEEK_SET);

    ret_str = malloc(size);
    fread(ret_str, 1, size, f);

    return ret_str;
  }

  return NULL;
}

int main(int argc, char ** argv)
{
  char input[BUFF_SIZE];
  char * tmp_ptr;
  char * flag;
  char * pass;

  if (argc != 3)
  {
    printf("Usage: %s <flag> <pass>\n", argv[0]);
    fflush(stdout);
    return 1;
  }

  printf("Enter password to read flag: ");
  fflush(stdout);

  fgets(input, BUFF_SIZE, stdin);
  tmp_ptr = strrchr(input, '\n');
  if (tmp_ptr != NULL)
  {
    tmp_ptr[0] = '\0';
  }

  flag = read_file(argv[1]);
  pass = read_file(argv[2]);

  if (flag == NULL || pass == NULL)
  {
    printf("Unexpected ERROR!\n");
    fflush(stdout);
    return 1;
  }

  if (strncmp(input, pass, strlen(input)) == 0)
  {
    printf("%s\n", flag);
    fflush(stdout);
  }
  else
  {
    printf("Wrong password\n");
    fflush(stdout);
  }

  free(flag);
  free(pass);
  
  printf("Goodbye\n");
  fflush(stdout);

  return 0;
}
