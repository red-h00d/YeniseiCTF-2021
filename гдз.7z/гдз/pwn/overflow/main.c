#include <stdio.h>

#define USER_INPUT 16

int main(int argc, char * argv[])
{
  char user_input[USER_INPUT];/*other variable definitions and statements*/
  unsigned char a = 0;

  printf("Welcome to out simple greeter V2!\n");

  scanf("%s", user_input);
  printf("Hello, ");
  printf("%s", user_input);
  printf("!\n");

  if (a == 42)
  {
    printf("yctf{********************************}\n");
  }

  return 0;
}
